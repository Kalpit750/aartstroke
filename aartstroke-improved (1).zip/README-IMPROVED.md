# Aart Stroke — Improved Website

Files:
- `index.html` — production dashboard / landing page
- `production-form.html` — production form, artwork upload, order records, CSV/Excel export and A4 print
- `making-process.html` — production-stage editor

The files keep the existing browser storage keys:
- `production-orders`
- `production-current-order`
- `production-form`
- `production-process`

Deployment:
1. Replace the three existing HTML files in the `Kalpit750/aartstroke` repository.
2. Commit and push to `main`.
3. GitHub Pages can then use `index.html` as the site entry point.

Important: order data is browser-local (`localStorage`). Export records regularly for backup.
